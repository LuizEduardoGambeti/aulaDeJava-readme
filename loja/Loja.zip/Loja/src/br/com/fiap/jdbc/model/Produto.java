package br.com.fiap.jdbc.model;

public class Produto {

	private int idProduto;
	private String nome;
	private String descricao;
	private int idCategoria;

	public Produto(String nome, String descricao) {
		this.nome = nome;
		this.descricao = descricao;
	}

	public Produto(int idProduto, String nome, String descricao) {

		this.idProduto = idProduto;
		this.nome = nome;
		this.descricao = descricao;

	}

	public long getIdProduto() {
		return idProduto;
	}

	public void setIdProduto(int idProduto) {
		this.idProduto = idProduto;
	}

	public String getNome() {
		return nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}
	
	@Override
	public String toString() {
		return String.format("O produto �: %d, %s,%s",this.nome,this.idProduto,this.descricao);
	}

}
