package br.com.fiap.jdbc.model;

import java.util.ArrayList;

public class Categoria {
	
	private int idCategoria;
	private String nome;
	
	private ArrayList<Produto> produtos = new ArrayList<Produto>();
	
	
	
	public void adicionar(Produto produto) {
		
		produtos.add(produto);
		
		
	}
	
	public long getIdCategoria() {
		return idCategoria;
	}

	public void setIdCategoria(int idCategoria) {
		this.idCategoria = idCategoria;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public ArrayList getProdutos() {
		return produtos;
	}

	public void setProdutos(ArrayList produtos) {
		this.produtos = produtos;
	}
	
	
	
}
