package testes;

import java.sql.SQLException;
import java.util.List;

import model.Usuario;
import repository.UsuarioDAO;

public class Teste {

	public static void main(String[] args) throws SQLException {
		
		UsuarioDAO dao = new UsuarioDAO();
		Usuario edu = new Usuario();
		Usuario adriane = new Usuario();
		
		
		edu.setId(1L);
		edu.setNome("Eduardo");
		edu.setEmail("edu.oliver410@gmail.com");
		edu.setTelefone(88459347);
		
		adriane.setId(2L);
		adriane.setNome("Adriane");
		adriane.setEmail("adriane410@gmail.com");
		adriane.setTelefone(8596506);
		
		
		dao.insert(adriane);
		dao.insert(edu);
		
		adriane.setNome("Colossetti");
		
		dao.insert(adriane);
		dao.update(adriane);
		dao.selectById(1L);
		dao.delete(1L);
		
		

	}

}
