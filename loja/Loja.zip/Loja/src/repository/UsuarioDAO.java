package repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import connectionFactory.connectionFactory;
import model.Usuario;

public class UsuarioDAO {

	private Connection conexao;

	public UsuarioDAO() {

		this.conexao = new connectionFactory().conectar();

	}

	public void insert(Usuario usuario) throws SQLException {

		String sql = "insert into usuarios(ID,NOME,EMAIL,TELEFONE,DATAREGISTRO) values (?,?,?,?,?)";
		PreparedStatement stmt = conexao.prepareStatement(sql);

		stmt.setLong(1, usuario.getId());
		stmt.setString(2, usuario.getNome());
		stmt.setString(3, usuario.getEmail());
		stmt.setLong(4, usuario.getTelefone());
		stmt.setDate(5, usuario.getDataRegistro());

		stmt.execute();
		stmt.close();

	}

	public List<Usuario> select() throws SQLException {

		List<Usuario> usuarios = new ArrayList<Usuario>();
		String sql = "select * from usuarios order by nome";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {

			Usuario usuario = new Usuario();
			usuario.setId(rs.getLong("ID"));
			usuario.setNome(rs.getString("NOME"));
			usuario.setEmail(rs.getString("EMAIL"));
			usuario.setTelefone(rs.getInt("TELEFONE"));
			usuario.setDataRegistro(rs.getDate("DATAREGISTRO"));

			usuarios.add(usuario);

		}

		rs.close();
		stmt.close();
		return usuarios;

	}

	public Usuario selectById(long id) throws SQLException {
		Usuario usuario = null;
		String sql = "select * from usuarios where ID=?";
		PreparedStatement stmt = conexao.prepareStatement(sql);
		stmt.setLong(1, id);
		ResultSet rs = stmt.executeQuery();

		while (rs.next()) {
			usuario = new Usuario();
			usuario.setId(rs.getLong("ID"));
			usuario.setNome(rs.getString("NOME"));
			usuario.setEmail(rs.getString("EMAIL"));
			usuario.setTelefone(rs.getInt("TELEFONE"));
			usuario.setDataRegistro(rs.getDate("DATAREGISTRO"));

		}

		rs.close();
		stmt.close();
		return usuario;

	}

	public void update(Usuario usuario) throws SQLException {

		String sql = "update USUARIOS set nome = ?,email = ?,telefone = ? where id = ?";

		PreparedStatement stmt = conexao.prepareStatement(sql);
		stmt.setString(1, usuario.getNome());
		stmt.setString(2, usuario.getEmail());
		stmt.setInt(3, usuario.getTelefone());
		stmt.setLong(4, usuario.getId());

		stmt.execute();
		stmt.close();

	}

	public void delete(long id) throws SQLException {

		String sql = "delete from usuarios where id = ?";

		PreparedStatement stmt = conexao.prepareStatement(sql);
		stmt.setLong(1, id);

		stmt.execute();
		stmt.close();
	}
}
