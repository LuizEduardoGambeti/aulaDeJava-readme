package teste;

import java.util.Scanner;

import listas.ListaIntCrescente;

public class MainTeste {

	public static void main(String[] args) {

		ListaIntCrescente lista = new ListaIntCrescente();

		Scanner le = new Scanner(System.in);
		System.out.print("Informe valor positivo para inserir ou negativo para sair: ");
		int valor = le.nextInt();

		while (valor >= 0) {
			lista.insere(valor);
			lista.show();
			System.out.print("Informe valor positivo para inserir ou negativo para sair: ");
			valor = le.nextInt();
		}

		System.out.println("A quantidade de n�s presentes na lista �:" + lista.contaNos());

		System.out.println("\n informe valor do limite inferiot do intervalo que deseja apresentar:");
		valor = le.nextInt();
		lista.showGreaters(valor);
		
		
		System.out.println("Informar valor positivo para remover ou negativo para sair.");
		valor = le.nextInt();
		while (valor >= 0) {
			lista.remove(valor);
			lista.show();
			System.out.println("Informar valor positivo para remover ou negativo para sair.");
			valor = le.nextInt();
		}

	}

}
