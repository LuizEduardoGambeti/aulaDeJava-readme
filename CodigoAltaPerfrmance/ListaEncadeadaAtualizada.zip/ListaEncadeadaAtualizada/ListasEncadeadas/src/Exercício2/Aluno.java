package Exerc�cio2;

public class Aluno {
	int rm;
	int media;

	public Aluno(int rm, int media) {
		super();
		this.rm = rm;
		this.media = media;
	}

	public int getRm() {
		return rm;
	}

	public void setRm(int rm) {
		this.rm = rm;
	}

	public int getMedia() {
		return media;
	}

	public void setMedia(int media) {
		this.media = media;
	}

	@Override
	public String toString() {
		return "Aluno [rm=" + rm + ", media=" + media + "]";
	}

}
