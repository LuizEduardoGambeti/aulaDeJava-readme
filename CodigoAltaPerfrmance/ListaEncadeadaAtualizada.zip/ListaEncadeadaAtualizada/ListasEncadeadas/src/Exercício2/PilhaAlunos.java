package Exerc�cio2;

import java.util.Scanner;

import listas.ListaAluno;

public class PilhaAlunos {
public static void main(String [] args) {
	ListaAluno turma = new ListaAluno();

	Scanner le = new Scanner(System.in);
	int opcao;
}

do {
	
	
	System.out.println("sair");
	System.out.println("Inserir aluno");
	System.out.println("remover aluno");
	System.out.println("op��o:");
	System.out.println("");
	opcao = le.nextInt();
}

}
